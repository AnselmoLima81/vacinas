#include "utente.h"

#ifndef LISTA_UTENTES
#define LISTA_UTENTES

typedef struct sListaUtentes
{
    Utente utentes[1000];
    int quantidade;
} ListaUtentes;

#endif

void acrestentaUtente(ListaUtentes *lu);
void gravarDadosListaUtentes(ListaUtentes lu);
void carregarDadosListaUtentes(ListaUtentes *lu);
void inativarUtente(ListaUtentes *lu, int nUtente);
void listarUtentesRegistados(ListaUtentes *lu);
int vacinarUtente(ListaUtentes *lu);
