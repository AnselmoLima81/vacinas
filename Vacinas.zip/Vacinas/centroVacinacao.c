#include "centroVacinacao.h"
#include <stdio.h>
#include <string.h>

CentroVacinacao criarCentroVacinacao()
{
    CentroVacinacao centroVacinacao;

    printf("\n\n");
    printf("| *********** Inserir Centro de Vacinacao ************ |\n");
    printf("| Codigo: ");
    scanf("%d", &centroVacinacao.codigo);

    printf("| Nome: ");
    while (getchar() != '\n')
        ;
    fgets(centroVacinacao.nome, 50, stdin);
    centroVacinacao.nome[strlen(centroVacinacao.nome) - 1] = '\0';

    printf("| Morada: ");
    while (getchar() != '\n')
        ;
    fgets(centroVacinacao.morada, 100, stdin);
    centroVacinacao.morada[strlen(centroVacinacao.morada) - 1] = '\0';

    centroVacinacao.activo = 1;

    return centroVacinacao;
}