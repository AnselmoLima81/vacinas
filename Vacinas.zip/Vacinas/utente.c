#include "utente.h"
#include <stdio.h>
#include <string.h>

Utente criarUtente()
{
    Utente utente;

    printf("\n\n");
    printf("| ****************** Inserir Utente ****************** |\n");
    printf("| Codigo: ");
    scanf("%d", &utente.codigo);

    printf("| Nome: ");
    while (getchar() != '\n')
        ;
    fgets(utente.nome, 60, stdin);
    utente.nome[strlen(utente.nome) - 1] = '\0';

    printf("| Idade: ");
    scanf("%d", &utente.idade);

    printf("| Telefone: ");
    scanf("%d", &utente.telefone);

    utente.diaUltimaDosagem = 0;
    utente.mesUltimaDosagem = 0;
    utente.anoUltimaDosagem = 0;
    utente.qtdDoses = 0;
    utente.codigoVacina = 0;

    utente.activo = 1;

    return utente;
}