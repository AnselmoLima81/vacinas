#include "vacina.h"

#define LISTA_VACINAS
#define LISTA_VACINAS

typedef struct sListaVacinas
{
    Vacina vacinas[100];
    int quantidade;
} ListaVacinas;

void acrestentaVacina(ListaVacinas *lv);
void gravarDadosListaVacinas(ListaVacinas lv);
void carregarDadosListaVacinas(ListaVacinas *lv);
void inativarVacina(ListaVacinas *lv, int nVacina);
ListaVacinas OrdenarVacinas(ListaVacinas *lv);
void listarVacinas(ListaVacinas *lv);
