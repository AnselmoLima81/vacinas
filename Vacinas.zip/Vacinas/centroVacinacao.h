#ifndef CENTRO_VACINACAO
#define CENTRO_VACINACAO

typedef struct sVacinacao
{
    int nUtente;
    int nVacina;
} Vacinacao;

typedef struct sCentroVacinacao
{
    int codigo;
    char nome[50];
    char morada[100];
    Vacinacao vacinacao[50];
    int activo;
} CentroVacinacao;

#endif

CentroVacinacao criarCentroVacinacao();