#include "listaCentroVacinacoes.h"
#include <stdio.h>

void acrestentaCentroVacinacao(ListaCentroVacinacoes *lcv)
{
    CentroVacinacao cv = criarCentroVacinacao(lcv->quantidade);
    lcv->centroVacinacoes[lcv->quantidade] = cv;
    lcv->quantidade++;
}

void gravarDadosListaCentroVacinacoes(ListaCentroVacinacoes lcv)
{
    FILE *ficheiro = fopen("listaCentroVacinacoes.dat", "wb");
    rewind(ficheiro);
    fwrite(&lcv, sizeof(ListaCentroVacinacoes), 1, ficheiro);
    fclose(ficheiro);
}

void carregarDadosListaCentros(ListaCentroVacinacoes *lcv)
{
    FILE *ficheiro;
    ficheiro = fopen("listaCentroVacinacoes.dat", "rb");
    if (ficheiro == NULL)
        return;
    fread(lcv, sizeof(ListaCentroVacinacoes), 1, ficheiro);
    fclose(ficheiro);
}

void inativarCentro(ListaCentroVacinacoes *lc, int nCentro)
{
    listarCentros(lc);

    printf("Centro a inativar: ");
    scanf("%d", nCentro);
    if (nCentro >= lc->quantidade + 1)
    {
        printf("Impossivel inativar.");
    }
    else
    {
        lc->centroVacinacoes[nCentro].activo = 0;
    }
}

void listarCentros(ListaCentroVacinacoes *lc)
{
    printf("\n\n");
    printf("| ***************** Lista de Centros ***************** |\n");
    printf("| Centros registados: %d \n", lc->quantidade);
    for (int i = 0; i < lc->quantidade; i++)
    {
        if (lc->centroVacinacoes[i].activo == 1)
        {
            printf("|   %d       %s            %s\n", lc->centroVacinacoes[i].codigo, lc->centroVacinacoes[i].nome, lc->centroVacinacoes[i].morada);
        }
    }
    printf("| **************************************************** |\n");
}