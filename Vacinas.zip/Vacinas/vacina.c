#include "vacina.h"
#include <stdio.h>
#include <string.h>

Vacina criarVacina()
{
    Vacina vacina;

    printf("\n\n");
    printf("| ****************** Inserir Vacina ****************** |\n");
    printf("| Codigo: ");
    scanf("%d", &vacina.codigo);

    printf("| Designacao: ");
    while (getchar() != '\n')
        ;
    fgets(vacina.designacao, 20, stdin);
    vacina.designacao[strlen(vacina.designacao) - 1] = '\0';

    printf("| Numero de Doses: ");
    scanf("%d", &vacina.nDoses);

    printf("| Tempo Entre Doses: ");
    scanf("%d", &vacina.tempoDoses);

    vacina.activo = 1;

    return vacina;
}