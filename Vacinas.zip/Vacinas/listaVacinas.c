#include "listaVacinas.h"
#include <stdio.h>
#include <string.h>

void acrestentaVacina(ListaVacinas *lv)
{
    Vacina v = criarVacina(lv->quantidade);
    lv->vacinas[lv->quantidade] = v;
    lv->quantidade++;
}

void gravarDadosListaVacinas(ListaVacinas lv)
{
    FILE *ficheiro = fopen("listaVacinas.dat", "wb");
    rewind(ficheiro);
    fwrite(&lv, sizeof(ListaVacinas), 1, ficheiro);
    fclose(ficheiro);
}

void carregarDadosListaVacinas(ListaVacinas *lv)
{
    FILE *ficheiro;
    ficheiro = fopen("listaVacinas.dat", "rb");
    if (ficheiro == NULL)
        return;
    fread(lv, sizeof(ListaVacinas), 1, ficheiro);
    fclose(ficheiro);
}

void inativarVacina(ListaVacinas *lv, int nVacina)
{
    listarVacinas(lv);

    printf("Vacina a inativar: ");
    scanf("%d", nVacina);
    if (nVacina >= lv->quantidade + 1)
    {
        printf("Impossivel inativar.");
    }
    else
    {
        lv->vacinas[nVacina].activo = 0;
    }
}

ListaVacinas OrdenarVacinas(ListaVacinas *lv)
{

    ListaVacinas listaVacinas;
    listaVacinas = *lv;

    int tamanho = listaVacinas.quantidade;
    int r;

    for (int i = 0; i < tamanho - 1; i++)
    {
        for (int j = i + 1; j < tamanho; j++)
        {
            r = strcmp(listaVacinas.vacinas[i].designacao, listaVacinas.vacinas[j].designacao);
            if (r > 0)
            {
                Vacina aux = listaVacinas.vacinas[j];
                listaVacinas.vacinas[j] = listaVacinas.vacinas[i];
                listaVacinas.vacinas[i] = aux;
            }
        }
    }

    return listaVacinas;
}

void listarVacinas(ListaVacinas *lv)
{
    OrdenarVacinas(lv);
    printf("\n\n");
    printf("| ***************** Lista de Vacinas ***************** |\n");
    printf("| Vacinas registadas: %d \n", lv->quantidade);
    printf("| Codigo - Designacao - N. Doses - T. Doses |\n");
    for (int i = 0; i < lv->quantidade; i++)
    {
        if (lv->vacinas[i].activo == 1)
        {
            printf("|   %d       %s            %d         %d\n", lv->vacinas[i].codigo, lv->vacinas[i].designacao, lv->vacinas[i].nDoses, lv->vacinas[i].tempoDoses);
        }
    }
    printf("| **************************************************** |\n");
}
