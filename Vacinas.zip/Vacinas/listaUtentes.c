#include "listaUtentes.h"
#include <stdio.h>
#include "vacina.h"

void acrestentaUtente(ListaUtentes *lu)
{
    Utente u = criarUtente(lu->quantidade);
    lu->utentes[lu->quantidade] = u;
    lu->quantidade++;
}

void gravarDadosListaUtentes(ListaUtentes lu)
{
    FILE *ficheiro = fopen("listaUtentes.dat", "wb");
    rewind(ficheiro);
    fwrite(&lu, sizeof(ListaUtentes), 1, ficheiro);
    fclose(ficheiro);
}

void carregarDadosListaUtentes(ListaUtentes *lu)
{
    FILE *ficheiro;
    ficheiro = fopen("listaUtentes.dat", "rb");
    if (ficheiro == NULL)
        return;
    fread(lu, sizeof(ListaUtentes), 1, ficheiro);
    fclose(ficheiro);
}

void inativarUtente(ListaUtentes *lu, int nUtente)
{
    listarUtentesRegistados(lu);

    printf("Utente a inativar: ");
    scanf("%d", nUtente);
    if (nUtente >= lu->quantidade + 1)
    {
        printf("Impossivel inativar.");
    }
    else
    {
        lu->utentes[nUtente].activo = 0;
    }
}

void listarUtentesRegistados(ListaUtentes *lu)
{

    printf("\n\n");
    printf("| ***************** Lista de Utentes ***************** |\n");
    printf("| Cod - Nome - Idade - Tel - Ultima Dos. - Qtd Doses - Vacina |\n");
    for (int i = 0; i < lu->quantidade; i++)
    {
        if (lu->utentes[i].activo == 1)
        {
            printf("| %d - %s - %d - %d - %d/%d/%d - %d - %d\n", lu->utentes[i].codigo, lu->utentes[i].nome,
                   lu->utentes[i].idade, lu->utentes[i].telefone, lu->utentes[i].diaUltimaDosagem,
                   lu->utentes[i].mesUltimaDosagem, lu->utentes[i].anoUltimaDosagem, lu->utentes[i].qtdDoses,
                   lu->utentes[i].codigoVacina);
        }
    }
    printf("| **************************************************** |\n");
}

int vacinarUtente(ListaUtentes *lu)
{

    int codigo = 0;
    int codCentroVacina = 0;
    int codVacina = 0;
    int dia = 0;
    int mes = 0;
    int ano = 0;

    int admvacInc;

    Vacina vc;

    vc.admVac++;
    printf("\n\n");
    printf("| ****************** Vacinar Utente ****************** |\n");
    printf("| Codigo Utente: ");
    scanf("%d", &codigo);

    printf("| Codigo Centro de Vacinacao: ");
    scanf("%d", &codCentroVacina);

    printf("| Codigo Vacina: ");
    scanf("%d", &codVacina);

    printf("| Data Ultima Dosagem (dd/mm/yyyy): ");
    scanf("%d/%d/%d", &dia, &mes, &ano);

    for (int i = 0; i < lu->quantidade; i++)
    {
        if (lu->utentes[i].codigo == codigo)
        {
            lu->utentes[i].codigoVacina = codVacina;
            lu->utentes[i].diaUltimaDosagem = dia;
            lu->utentes[i].mesUltimaDosagem = mes;
            lu->utentes[i].anoUltimaDosagem = ano;
            lu->utentes[i].qtdDoses++;
        }
    }
    return vc.admVac;
}

//quantidade de vacinas através da lu para a dashboard
//media de idade através da lu para a dashboard
//qtd de utentes vacinados por vacina
