#include "listaVacinas.h"
#include "listaUtentes.h"
#include "listaCentroVacinacoes.h"
#include <stdio.h>

void listarUtentesPorVacina(ListaUtentes *lu, ListaVacinas *lv)
{

    printf("\n\n");
    printf("| *********** Lista de Utentes por Vacina ************ |\n");
    printf("| Vacina - Quantidade |\n");
    for (int i = 0; i < lv->quantidade; i++)
    {
        int quantidadeUtentes = 0;
        for (int j = 0; j < lu->quantidade; j++)
        {
            if (lu->utentes[j].codigoVacina == lv->vacinas[i].codigo)
            {
                quantidadeUtentes++;
            }
        }
        printf("| %s - %d\n", lv->vacinas[i].designacao, quantidadeUtentes);
    }
    printf("| **************************************************** |\n");
}

int main(int argc, char const *argv[])
{

    ListaVacinas lv;
    lv.quantidade = 0;

    ListaUtentes lu;
    lu.quantidade = 0;

    ListaCentroVacinacoes lcv;
    lcv.quantidade = 0;

    Vacina vc;

    //Dashboard media;

    int opcao = -1;
    int nVacina;
    int nUtente;
    int nCentro;

    carregarDadosListaVacinas(&lv);
    carregarDadosListaUtentes(&lu);
    carregarDadosListaCentros(&lcv);

    while (opcao != 0)
    {

        printf("\n\n");
        printf("| ********************* DASHBOARD ******************** |\n");
        printf("| Quantidade de vacinas administradas:\n");
        printf("| Media de idades dos utentes vacinados: \n");
        printf("| Quantidade de utentes vacinados por vacina: \n");
        printf("| *********************** MENU *********************** |\n");
        printf("| 1 - Inserir Vacina \n");
        printf("| 2 - Listar Vacinas por ordem alfabetica \n");
        printf("| 3 - Inserir Utente \n");
        printf("| 4 - Listar Utentes Registados \n");
        printf("| 5 - Inserir Centro de Vacinacao \n");
        printf("| 6 - Listar Centro de Vacinacao \n");
        printf("| 7 - Vacinar Utente \n");
        printf("| 8 - Listar Utentes por Vacina \n");
        printf("| 9 - Inativar Vacina\n");
        printf("| 10 - Inativar Centro Vacinacao\n");
        printf("| 11 - Inativar Utente\n");
        printf("| 0 - Sair \n");
        printf("| **************************************************** |\n");
        printf("| Introduza uma Opcao: ");
        scanf("%d", &opcao);

        switch (opcao)
        {
        case 1:
            acrestentaVacina(&lv);
            gravarDadosListaVacinas(lv);
            break;
        case 2:
            listarVacinas(&lv);
            break;
        case 3:
            acrestentaUtente(&lu);
            gravarDadosListaUtentes(lu);
            break;
        case 4:
            listarUtentesRegistados(&lu);
            break;
        case 5:
            acrestentaCentroVacinacao(&lcv);
            gravarDadosListaCentroVacinacoes(lcv);
            break;
        case 6:
            listarCentros(&lcv);
            break;
        case 7:
            vacinarUtente(&lu);
            break;
        case 8:
            listarUtentesPorVacina(&lu, &lv);
            break;
        case 9:
            inativarVacina(&lv, nVacina);
            gravarDadosListaVacinas(lv);
            break;
        case 10:
            inativarCentro(&lcv, nCentro);
            gravarDadosListaCentroVacinacoes(lcv);
            break;
        case 11:
            inativarUtente(&lu, nUtente);
            gravarDadosListaUtentes(lu);
            break;
        case 0:
            break;
        default:
            printf("| Opcao invalida \n");
            break;
        }
        printf("| Quantidade de vacinas administradas: %d", vc.admVac);
    }
}