#include "centroVacinacao.h"

#define LISTA_CENTRO_VACINACAO
#define LISTA_CENTRO_VACINACAO

typedef struct sListaCentroVacinacoes
{
    CentroVacinacao centroVacinacoes[500];
    int quantidade;
} ListaCentroVacinacoes;

void acrestentaCentroVacinacao(ListaCentroVacinacoes *lcv);
void gravarDadosListaCentroVacinacoes(ListaCentroVacinacoes lcv);
void carregarDadosListaCentros(ListaCentroVacinacoes *lcv);
void inativarCentro(ListaCentroVacinacoes *lc, int nCentro);
void listarCentros(ListaCentroVacinacoes *lc);