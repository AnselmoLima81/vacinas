#ifndef VACINA
#define VACINA

typedef struct sVacina
{
    int codigo;
    char designacao[20];
    int nDoses;
    int tempoDoses;
    int admVac;
    int activo;
} Vacina;

#endif

Vacina criarVacina();