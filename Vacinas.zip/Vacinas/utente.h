#ifndef UTENTE
#define UTENTE

typedef struct sUtente
{
    int codigo;
    char nome[60];
    int idade;
    int telefone;
    int diaUltimaDosagem;
    int mesUltimaDosagem;
    int anoUltimaDosagem;
    int dataUltimaDosagem;
    int qtdDoses;
    int codigoVacina;
    int activo;
} Utente;

#endif

Utente criarUtente();
